/**
 * Compatibility backfill for Codex models released after the pinned pi-ai
 * catalog. The transport and OAuth implementation stay owned by pi-ai; this
 * module only supplies model metadata that pi-ai 0.87.1 added upstream.
 *
 * Existing catalog entries always win, so a future pi-ai upgrade can absorb
 * these models without duplicates or local metadata overriding upstream.
 *
 * @module dsh-codex-oauth/catalog
 */
import type { Model, Provider } from '@earendil-works/pi-ai';
type CodexModel = Model<'openai-codex-responses'>;
type CodexProvider = Provider<'openai-codex-responses'>;
/** Add only missing GPT-6 Codex models to a pi-ai catalog. */
export declare function backfillGpt6CodexModels(models: readonly CodexModel[]): readonly CodexModel[];
/** Wrap a pi-ai Codex provider without changing its OAuth or stream implementation. */
export declare function withGpt6CodexModels(provider: CodexProvider): CodexProvider;
export {};
