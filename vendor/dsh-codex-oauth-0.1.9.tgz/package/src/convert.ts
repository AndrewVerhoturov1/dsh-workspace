/**
 * Harness request/stream vocabulary conversion for the Codex adapter.
 *
 * The request half projects `GenerateOptions` history into pi-ai's `Context`
 * (text-only: image blocks are refused before conversion), treating every
 * historical assistant message as provider-neutral content. The stream half
 * translates pi-ai assistant events into harness `StreamChunk`s.
 *
 * Both halves are adapted from `@deepseek-ai/dsh-llm-pi-ai` (MIT, © DeepSeek
 * AI) — `context.ts` and `stream.ts` — with image attachment support and
 * provider-native replay state omitted.
 *
 * @module dsh-codex-oauth/convert
 */

import {
  CallId,
  contentHasImage,
  LlmError,
  offloadRequestImagesWithPolicy,
  requestImageHandleText,
} from '@deepseek-ai/dsh-llm'
import type { ContentBlock, FinishReason, GenerateOptions, Message, StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm'
import type {
  AttachmentStore,
  ImageAttachmentRef,
  ImageRequestPolicy,
  RequestImageAttachment,
} from '@deepseek-ai/dsh-attachment'
import {
  CONTEXT_WINDOW_EXCEEDED_CODE,
  EMPTY_RESPONSE_CODE,
  QUOTA_EXCEEDED_CODE,
  isContextWindowExceededError,
  isQuotaExceededError,
} from '@deepseek-ai/dsh-llm'
import type {
  AssistantMessage,
  AssistantMessageEvent,
  Context as PiContext,
  ImageContent,
  Message as PiMessage,
  Tool as PiTool,
  TextContent,
  Usage as PiUsage,
} from '@earendil-works/pi-ai'
import { isContextOverflow } from '@earendil-works/pi-ai'

/** Parse tool-call argument JSON; tolerate model malformations with {}. */
function parseArguments(raw: string): Record<string, unknown> {
  try {
    const parsed: unknown = JSON.parse(raw)
    if (typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>
    }
  } catch {
    // fall through
  }
  return {}
}

/** The zero usage value pi-ai requires on historical assistant messages. */
function emptyPiUsage(): PiUsage {
  return {
    input: 0,
    output: 0,
    cacheRead: 0,
    cacheWrite: 0,
    totalTokens: 0,
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
  }
}

/** Join the text blocks of one harness message. */
function flattenText(message: Message): string {
  return message.content
    .filter(block => block.type === 'text')
    .map(block => block.text)
    .join('')
}

/** Flatten text recursively inside one tool result. */
function toolResultText(blocks: readonly ContentBlock[]): string {
  return blocks.map(block => block.type === 'text'
    ? block.text
    : block.type === 'tool-result' ? toolResultText(block.content) : '').join('')
}

/**
 * Convert one historical harness assistant message into provider-neutral
 * pi-ai history. No replay state is produced or consumed: durable content is
 * the whole record, which pi-ai serializes as ordinary foreign history.
 * @param message - the harness assistant message.
 * @returns the pi-ai assistant message.
 */
function foreignAssistant(message: Message): AssistantMessage {
  const source = message.source.kind === 'model' ? message.source : undefined
  const content: AssistantMessage['content'] = []
  for (const block of message.content) {
    switch (block.type) {
      case 'text': content.push({ type: 'text', text: block.text }); break
      case 'reasoning': content.push({ type: 'thinking', thinking: block.text }); break
      case 'tool-call': content.push({
        type: 'toolCall',
        id: block.id,
        name: block.name,
        arguments: parseArguments(block.arguments),
      }); break
      case 'image':
        throw new LlmError('dsh-codex-oauth cannot represent historical assistant image output', 'UNSUPPORTED_CONTENT')
      default:
        // Plugin-added harness blocks are not pi-ai vocabulary.
        break
    }
  }
  return {
    role: 'assistant',
    content,
    // Deliberately not a catalog API: foreign history is never replay state.
    api: 'dsh-foreign',
    provider: source?.provider ?? 'dsh-foreign',
    model: source?.model ?? 'dsh-foreign',
    usage: emptyPiUsage(),
    stopReason: content.some(piece => piece.type === 'toolCall') ? 'toolUse' : 'stop',
    timestamp: 0,
  }
}

/** Project harness tool schemas into pi-ai's tool vocabulary. */
function toolsOf(options: GenerateOptions): PiTool[] | undefined {
  const tools = options.tools?.map(tool => ({
    name: tool.name,
    description: tool.description,
    // ToolSchema.parameters is JSON Schema; pi-ai's TSchema is structurally JSON Schema.
    parameters: tool.parameters,
  }))
  return tools !== undefined && tools.length > 0 ? tools : undefined
}

/**
 * Convert Harness history into a pi-ai `Context`.
 * Tool-result names are recovered from preceding assistant tool calls.
 * @param options - the harness request; `options.system` maps to pi-ai's single `systemPrompt` slot.
 * @returns the pi-ai context.
 */
const MAX_REQUEST_IMAGE_BYTES = 20 * 1024 * 1024
const REQUEST_IMAGE_POLICY: ImageRequestPolicy = {
  maxPixels: 2048 * 2048,
  maxBytes: 1024 * 1024,
}

function assertSupportedImageRoles(messages: readonly Message[]): void {
  for (const message of messages) {
    if (message.role === 'assistant' && contentHasImage(message.content)) {
      throw new LlmError('dsh-codex-oauth cannot represent historical assistant image output', 'UNSUPPORTED_CONTENT')
    }
    if (message.role !== 'user' && contentHasImage(message.content)) {
      throw new LlmError(`pi-ai cannot represent an image in an in-history ${message.role} message`, 'UNSUPPORTED_CONTENT')
    }
  }
}

function collectImageRefs(
  blocks: readonly ContentBlock[],
  refs: Map<ImageAttachmentRef['attachmentId'], ImageAttachmentRef>,
): void {
  for (const block of blocks) {
    if (block.type === 'image') refs.set(block.attachment.attachmentId, block.attachment)
    else if (block.type === 'tool-result') collectImageRefs(block.content, refs)
  }
}

async function prepareRequestImages(
  messages: readonly Message[],
  attachments: AttachmentStore,
  policy: ImageRequestPolicy,
  signal?: AbortSignal,
): Promise<Map<ImageAttachmentRef['attachmentId'], RequestImageAttachment>> {
  const refs = new Map<ImageAttachmentRef['attachmentId'], ImageAttachmentRef>()
  for (const message of messages) collectImageRefs(message.content, refs)
  const orderedRefs = [...refs.values()]
  const prepared = await Promise.all(orderedRefs.map(ref => attachments.readImageRequest(ref, policy, signal)))
  const versions = new Map<ImageAttachmentRef['attachmentId'], RequestImageAttachment>()
  for (const [index, ref] of orderedRefs.entries()) versions.set(ref.attachmentId, prepared[index] as RequestImageAttachment)
  return versions
}

async function userContent(
  blocks: readonly ContentBlock[],
  requestImages: ReadonlyMap<ImageAttachmentRef['attachmentId'], RequestImageAttachment>,
): Promise<string | (TextContent | ImageContent)[]> {
  const content: (TextContent | ImageContent)[] = []
  for (const block of blocks) {
    switch (block.type) {
      case 'text':
        if (block.text.length > 0) content.push({ type: 'text', text: block.text })
        break
      case 'image': {
        const version = requestImages.get(block.attachment.attachmentId)
        if (version === undefined) throw new LlmError('Harness image was not prepared for the pi-ai request', 'UNSUPPORTED_CONTENT')
        content.push({ type: 'text', text: requestImageHandleText(version) })
        content.push({ type: 'image', data: Buffer.from(version.data).toString('base64'), mimeType: version.mediaType })
        break
      }
      case 'tool-result': {
        const nested = await userContent(block.content, requestImages)
        if (typeof nested === 'string') {
          if (nested.length > 0) content.push({ type: 'text', text: nested })
        } else content.push(...nested)
        break
      }
      default:
        // Other merge-extensible blocks are not user-input vocabulary for pi-ai.
        break
    }
  }
  if (content.every(block => block.type === 'text')) return content.map(block => block.text).join('')
  return content
}

async function contextWithImages(options: GenerateOptions, attachments: AttachmentStore): Promise<PiContext> {
  assertSupportedImageRoles(options.messages)
  const requestMessages = offloadRequestImagesWithPolicy(options.messages, {
    representation: 'base64',
    maxBytes: MAX_REQUEST_IMAGE_BYTES,
    byteQuantum: 1,
    byteLength: ref => Math.min(ref.bytes, REQUEST_IMAGE_POLICY.maxBytes),
  })
  const requestImages = await prepareRequestImages(requestMessages, attachments, REQUEST_IMAGE_POLICY, options.signal)
  const exactMessages = offloadRequestImagesWithPolicy(requestMessages, {
    representation: 'base64',
    maxBytes: MAX_REQUEST_IMAGE_BYTES,
    byteQuantum: 1,
    byteLength: ref => requestImages.get(ref.attachmentId)?.bytes ?? ref.bytes,
  })

  const toolNames = new Map<CallId, string>()
  const messages: PiMessage[] = []
  for (const message of exactMessages) {
    if (message.role === 'system') {
      messages.push({ role: 'user', content: flattenText(message), timestamp: 0 })
      continue
    }
    if (message.role === 'assistant') {
      const assistant = foreignAssistant(message)
      for (const block of assistant.content) {
        if (block.type === 'toolCall') toolNames.set(CallId(block.id), block.name)
      }
      messages.push(assistant)
      continue
    }

    const regular = message.content.filter(block => block.type !== 'tool-result')
    const content = await userContent(regular, requestImages)
    const results = message.content.filter((block): block is Extract<ContentBlock, { type: 'tool-result' }> => (
      block.type === 'tool-result'
    ))
    if (content.length > 0 || results.length === 0) messages.push({ role: 'user', content, timestamp: 0 })
    for (const result of results) {
      const resultContent = await userContent(result.content, requestImages)
      messages.push({
        role: 'toolResult',
        toolCallId: result.toolCallId,
        toolName: toolNames.get(result.toolCallId) ?? 'unknown',
        content: typeof resultContent === 'string'
          ? [{ type: 'text', text: resultContent || '(no output)' }]
          : resultContent,
        isError: result.isError ?? false,
        timestamp: 0,
      })
    }
  }

  const tools = toolsOf(options)
  return {
    ...options.system !== undefined ? { systemPrompt: options.system } : {},
    messages,
    ...tools === undefined ? {} : { tools },
  }
}

export async function toCodexContext(options: GenerateOptions, attachments?: AttachmentStore): Promise<PiContext> {
  if (options.messages.some(message => contentHasImage(message.content))) {
    if (attachments === undefined) {
      throw new LlmError('pi-ai image input requires the durable attachment service', 'UNSUPPORTED_CONTENT')
    }
    return contextWithImages(options, attachments)
  }
  const toolNames = new Map<CallId, string>()
  const messages: PiMessage[] = []
  for (const message of options.messages) {
    if (contentHasImage(message.content)) {
      throw new LlmError('dsh-codex-oauth does not support image input', 'UNSUPPORTED_CONTENT')
    }
    if (message.role === 'system') {
      messages.push({ role: 'user', content: flattenText(message), timestamp: 0 })
      continue
    }
    if (message.role === 'assistant') {
      const assistant = foreignAssistant(message)
      for (const block of assistant.content) {
        if (block.type === 'toolCall') toolNames.set(CallId(block.id), block.name)
      }
      messages.push(assistant)
      continue
    }
    const text = flattenText(message)
    const results = message.content.filter(block => block.type === 'tool-result')
    if (text.length > 0 || results.length === 0) messages.push({ role: 'user', content: text, timestamp: 0 })
    for (const result of results) {
      messages.push({
        role: 'toolResult',
        toolCallId: result.toolCallId,
        toolName: toolNames.get(result.toolCallId) ?? 'unknown',
        content: [{ type: 'text', text: toolResultText(result.content) || '(no output)' }],
        isError: result.isError ?? false,
        timestamp: 0,
      })
    }
  }
  const tools = toolsOf(options)
  return {
    ...options.system !== undefined ? { systemPrompt: options.system } : {},
    messages,
    ...tools === undefined ? {} : { tools },
  }
}

/**
 * Map pi-ai usage to harness counts (pi-ai folds reasoning into output).
 * @param usage - cumulative usage from the terminal pi-ai event.
 * @returns harness counts; cache fields appear only when non-zero.
 */
export function mapUsage(usage: PiUsage): TokenUsage {
  return {
    inputTokens: usage.input,
    outputTokens: usage.output,
    ...usage.cacheRead > 0 ? { cacheReadTokens: usage.cacheRead } : {},
    ...usage.cacheWrite > 0 ? { cacheWriteTokens: usage.cacheWrite } : {},
  }
}

/**
 * Classify a flattened pi-ai provider error message into a harness code.
 * pi-ai flattens the caught error to `error.message`, so classification
 * pattern-matches provider wording.
 * @param message - the provider error text.
 * @returns the harness error code.
 */
function classifyPiAiError(message: string): string {
  if (/\bprovider is not configured\b/i.test(message)) return 'AUTH'
  if (/\b(?:401|403)\b/.test(message)) return 'AUTH'
  if (isQuotaExceededError(message)) return QUOTA_EXCEEDED_CODE
  if (/\b429\b|rate.?limit/i.test(message)) return 'RATE_LIMIT'
  if (/\b400\b|invalid.?request/i.test(message)) return 'INVALID_REQUEST'
  if (/\b5\d\d\b/.test(message)) return 'SERVER'
  if (/\btime(?:d)?\s*out\b|timeout/i.test(message)) return 'TIMEOUT'
  if (/stream ended (?:before|without)\b/i.test(message)) return 'TRANSPORT'
  if (/\b(?:network|connection|socket|fetch)\b|\bECONN[A-Z]+\b/i.test(message)
    || /\b(?:other side closed|HTTP2 request did not get a response|WebSocket closed unexpectedly|terminated|premature close)\b/i.test(message)) {
    return 'TRANSPORT'
  }
  return 'PI_AI_ERROR'
}

/**
 * Map a terminal pi-ai message to the harness finish reason.
 * @param message - the assistant message carried by the `done` or `error` event.
 * @param contextWindow - resolved catalog capacity for usage-based overflow detection.
 * @returns the mapped harness reason.
 */
export function mapStopReason(message: AssistantMessage, contextWindow?: number): FinishReason {
  const piAiOverflow = isContextOverflow(message, contextWindow)
  const harnessOverflow = message.stopReason === 'error'
    && message.errorMessage !== undefined
    && isContextWindowExceededError(message.errorMessage)
  if (piAiOverflow || harnessOverflow) {
    return {
      kind: 'error',
      failure: {
        message: message.errorMessage ?? `pi-ai detected context overflow for model "${message.model}"`,
        code: CONTEXT_WINDOW_EXCEEDED_CODE,
      },
    }
  }

  switch (message.stopReason) {
    case 'stop':
      if (message.content.length === 0) {
        return {
          kind: 'error',
          failure: {
            message: `model "${message.model}" returned a completed response with no content`,
            code: EMPTY_RESPONSE_CODE,
          },
        }
      }
      return { kind: 'stop' }
    case 'length': return { kind: 'max-tokens' }
    case 'toolUse': return { kind: 'tool-calls' }
    case 'aborted': return {
      kind: 'aborted',
      failure: { message: message.errorMessage ?? 'pi-ai stream aborted', code: 'ABORTED' },
    }
    case 'error': {
      const text = message.errorMessage ?? 'pi-ai stream error'
      const code = classifyPiAiError(text)
      return {
        kind: 'error',
        failure: {
          message: /provider is not configured/i.test(text)
            ? `${text}; log in first with \`dsh-codex-oauth login\` (or /codex login)`
            : text,
          code,
        },
      }
    }
    case 'pending':
    case 'deferred':
      return {
        kind: 'error',
        failure: {
          message: `model "${message.model}" ended a request unexpectedly (${message.stopReason})`,
          code: 'PI_AI_ERROR',
        },
      }
  }
}

/**
 * Translate the pi-ai event stream into harness `StreamChunk`s. pi-ai never
 * throws mid-stream — failures arrive as `error` events, which become
 * error/aborted `finish` chunks.
 * @param events - one assistant turn's pi-ai event stream.
 * @param contextWindow - resolved catalog capacity for usage-based overflow detection.
 * @returns the harness chunks, ending with `usage` then `finish`; throws
 *   `LlmError` (`STREAM_CLOSED`) if the source ends without a terminal event.
 */
export async function* toStreamChunks(
  events: AsyncIterable<AssistantMessageEvent>,
  contextWindow?: number,
): AsyncGenerator<StreamChunk> {
  const toolIds = new Map<number, { id: string; name: string }>()

  for await (const event of events) {
    switch (event.type) {
      case 'start':
        break
      case 'text_start':
        yield { type: 'block-start', index: event.contentIndex, blockType: 'text' }
        break
      case 'text_delta':
        yield { type: 'text-delta', index: event.contentIndex, text: event.delta }
        break
      case 'text_end':
        yield { type: 'block-end', index: event.contentIndex, block: { type: 'text', text: event.content } }
        break
      case 'thinking_start':
        yield { type: 'block-start', index: event.contentIndex, blockType: 'reasoning' }
        break
      case 'thinking_delta':
        yield { type: 'reasoning-delta', index: event.contentIndex, text: event.delta }
        break
      case 'thinking_end':
        yield { type: 'block-end', index: event.contentIndex, block: { type: 'reasoning', text: event.content } }
        break
      case 'toolcall_start': {
        const partial = event.partial.content[event.contentIndex]
        const id = partial?.type === 'toolCall' ? partial.id : ''
        const name = partial?.type === 'toolCall' ? partial.name : ''
        toolIds.set(event.contentIndex, { id, name })
        yield { type: 'block-start', index: event.contentIndex, blockType: 'tool-call' }
        break
      }
      case 'toolcall_delta': {
        const known = toolIds.get(event.contentIndex)
        yield {
          type: 'tool-call-delta',
          index: event.contentIndex,
          id: CallId(known?.id ?? ''),
          ...known?.name !== undefined && known.name.length > 0 ? { name: known.name } : {},
          argumentsDelta: event.delta,
        }
        break
      }
      case 'toolcall_end':
        yield {
          type: 'block-end',
          index: event.contentIndex,
          block: {
            type: 'tool-call',
            id: CallId(event.toolCall.id),
            name: event.toolCall.name,
            // pi-ai hands back parsed arguments; the harness keeps the raw string.
            arguments: JSON.stringify(event.toolCall.arguments),
          },
        }
        break
      case 'done':
        yield { type: 'usage', usage: mapUsage(event.message.usage) }
        yield { type: 'finish', reason: mapStopReason(event.message, contextWindow) }
        return
      case 'error':
        yield { type: 'usage', usage: mapUsage(event.error.usage) }
        yield { type: 'finish', reason: mapStopReason(event.error, contextWindow) }
        return
    }
  }
  throw new LlmError('pi-ai event stream ended without done/error', 'STREAM_CLOSED')
}
